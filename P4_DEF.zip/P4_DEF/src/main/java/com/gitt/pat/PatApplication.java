package com.gitt.pat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatApplication.class, args);
	}

}
