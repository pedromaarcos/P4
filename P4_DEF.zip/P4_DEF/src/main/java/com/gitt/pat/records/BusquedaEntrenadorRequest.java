package com.gitt.pat.records;

import jakarta.annotation.Nullable;

public record BusquedaEntrenadorRequest(
        @Nullable String nombreEntrenador,
        @Nullable String apellidoEntrenador1
) {}
