package com.gitt.pat.records;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CambioNombreEquipoRequest(
        @NotBlank(message = "El nuevo nombre es obligatorio")
        @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres")
        String nuevoNombre
) {}
