package com.gitt.pat.controllers;

import com.gitt.pat.records.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class Controlador {
    private final Map<String, ModeloEquipo> equipos = new HashMap<>();
    private final Map<String, ModeloEntrenador> entrenadores = new HashMap<>();
    private final Map<String, List<ModeloJugador>> jugadoresPorEquipo = new HashMap<>();
    private final Map<String, Set<Integer>> dorsalesPorEquipo = new HashMap<>();

    private static final int MAX_EQUIPOS = 3;
    private static final int MAX_JUGADORES = 3;

    //EQUIPOS
    @PostMapping("/api/equipos")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<String> crearEquipo(@RequestBody @Valid ModeloEquipo equipo) {
        // Verificar límite de equipos
        if (equipos.size() >= MAX_EQUIPOS) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("No se pueden registrar más equipos. Límite alcanzado (" + MAX_EQUIPOS + ")");
        }

        if (equipos.containsKey(equipo.nombreEquipo())) {
            return ResponseEntity.badRequest().body("El equipo ya existe");
        }

        equipos.put(equipo.nombreEquipo(), equipo);
        return ResponseEntity.status(HttpStatus.CREATED).body("Equipo '" + equipo.nombreEquipo() + "' creado correctamente");
    }

    @GetMapping("/api/equipos")
    public ResponseEntity<List<Map<String, Object>>> listarEquipos() {
        List<Map<String, Object>> equiposInfo = new ArrayList<>();

        equipos.forEach((nombreEquipo, equipo) -> {
            Map<String, Object> infoEquipo = new LinkedHashMap<>();
            infoEquipo.put("nombre", nombreEquipo);
            infoEquipo.put("tieneEntrenador", entrenadores.containsKey(nombreEquipo));
            infoEquipo.put("totalJugadores", jugadoresPorEquipo.getOrDefault(nombreEquipo, List.of()).size());

            equiposInfo.add(infoEquipo);
        });

        return ResponseEntity.ok(equiposInfo);
    }

    @GetMapping("/api/equipos/{equipo}")
    public ResponseEntity<?> obtenerEquipoCompleto(@PathVariable String equipo) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + equipo + "' no existe");
        }
        Map<String, Object> respuesta = new LinkedHashMap<>();
        List<String> jugadoresFormateados = new ArrayList<>();
        List<ModeloJugador> jugadores = jugadoresPorEquipo.getOrDefault(equipo, Collections.emptyList());

        ModeloEntrenador entrenador = entrenadores.get(equipo);
        String entrenadorStr = entrenador != null
                ? String.format("%s %s", entrenador.nombreEntrenador(), entrenador.apellidoEntrenador1())
                : "Sin entrenador asignado";


        for (ModeloJugador jugador : jugadores) {
            String jugadorStr = String.format("%s %s, Dorsal %d",
                    jugador.nombreJugador(),
                    jugador.apellidoJugador1(),
                    jugador.dorsalJugador());
            jugadoresFormateados.add(jugadorStr);
        }

        respuesta.put("nombreEquipo", equipo);
        respuesta.put("Entrenador", entrenador != null ? entrenadorStr: null);
        respuesta.put("Numero de jugadores", jugadores.size());
        respuesta.put("Jugadores", jugadoresFormateados);

        return ResponseEntity.ok(respuesta);

    }

    @GetMapping("/api/equipos/{equipo}/dorsales-usados")
    public ResponseEntity<?> obtenerDorsalesUsados(@PathVariable String equipo) {
        // Verificar si el equipo existe
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El equipo '" + equipo + "' no existe");
        }

        Set<Integer> dorsales = dorsalesPorEquipo.getOrDefault(equipo, Collections.emptySet());

        int[] dorsalesArray = dorsales.stream().mapToInt(Integer::intValue).toArray();

        if (dorsalesArray.length == 0) {
            return ResponseEntity.ok("No hay dorsales asignados en el equipo " + equipo);
        }
        return ResponseEntity.ok(dorsalesArray);
    }

    @DeleteMapping("/api/equipos/{nombre}")
    public ResponseEntity<String> eliminarEquipo(@PathVariable String nombre) {
        if (!equipos.containsKey(nombre)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Equipo '" + nombre + "' no encontrado");
        }
        equipos.remove(nombre);
        dorsalesPorEquipo.remove(nombre);
        jugadoresPorEquipo.remove(nombre);
        return ResponseEntity.ok("Equipo '" + nombre + "' eliminado correctamente");
    }

    @PutMapping("/api/equipos/{nombreActual}")
    public ResponseEntity<?> cambiarNombreEquipo(
            @PathVariable String nombreActual,
            @RequestBody @Valid CambioNombreEquipoRequest nuevoNombre) {
        if (!equipos.containsKey(nombreActual)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + nombreActual + "' no existe");
        }

        // Verificar si el nuevo nombre ya está en uso
        if (equipos.containsKey(nuevoNombre.nuevoNombre())) {
            return ResponseEntity.badRequest().body("Ya existe un equipo con el nombre '" + nuevoNombre.nuevoNombre() + "'");
        }

        ModeloEquipo equipo = equipos.remove(nombreActual);

        ModeloEquipo equipoActualizado = new ModeloEquipo(nuevoNombre.nuevoNombre());
        equipos.put(nuevoNombre.nuevoNombre(), equipoActualizado);

        if (entrenadores.containsKey(nombreActual)) {
            ModeloEntrenador entrenador = entrenadores.remove(nombreActual);
            ModeloEntrenador entrenadorActualizado = new ModeloEntrenador(
                    entrenador.nombreEntrenador(),
                    entrenador.apellidoEntrenador1(),
                    nuevoNombre.nuevoNombre()
            );
            entrenadores.put(nuevoNombre.nuevoNombre(), entrenadorActualizado);
        }

        if (jugadoresPorEquipo.containsKey(nombreActual)) {
            List<ModeloJugador> jugadores = jugadoresPorEquipo.remove(nombreActual);
            List<ModeloJugador> jugadoresActualizados = jugadores.stream()
                    .map(j -> new ModeloJugador(
                            j.nombreJugador(),
                            j.apellidoJugador1(),
                            j.dorsalJugador(),
                            nuevoNombre.nuevoNombre()
                    ))
                    .collect(Collectors.toList());
            jugadoresPorEquipo.put(nuevoNombre.nuevoNombre(), jugadoresActualizados);
        }

        if (dorsalesPorEquipo.containsKey(nombreActual)) {
            dorsalesPorEquipo.put(nuevoNombre.nuevoNombre(), dorsalesPorEquipo.remove(nombreActual));
        }

        return ResponseEntity.ok(
                String.format("Nombre del equipo cambiado de '%s' a '%s'",
                        nombreActual,
                        nuevoNombre.nuevoNombre())
        );
    }


    //ENTERNADORES
    @PostMapping("/api/equipos/{equipo}/entrenador")
    public ResponseEntity<?> crearEntrenador(@PathVariable String equipo, @RequestBody @Valid ModeloEntrenador entrenador) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + equipo + "' no existe");
        }
        if (entrenadores.containsKey(equipo)) {
            return ResponseEntity.badRequest().body("Este equipo ya tiene un entrenador");
        }
        ModeloEntrenador nuevoEntrenador = new ModeloEntrenador(
                entrenador.nombreEntrenador(),
                entrenador.apellidoEntrenador1(),
                equipo
        );
        entrenadores.put(equipo, nuevoEntrenador);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoEntrenador);
    }

    @GetMapping("/api/equipos/{equipo}/entrenador")
    public ResponseEntity<String> obtenerEntrenador(@PathVariable String equipo) {
        ModeloEntrenador entrenador = entrenadores.get(equipo);
        if (entrenador == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró entrenador para " + equipo);
        }
        return ResponseEntity.ok(String.format("El entrenador de %s es %s %s",
                equipo,
                entrenador.nombreEntrenador(),
                entrenador.apellidoEntrenador1()));
    }

    @PostMapping("/api/entrenadores/buscar")
    public ResponseEntity<?> buscarEntrenador(@RequestBody @Valid BusquedaEntrenadorRequest request) {
        if (request.nombreEntrenador() == null &&
                request.apellidoEntrenador1() == null) {
            return ResponseEntity.badRequest()
                    .body("Debe proporcionar al menos un criterio de búsqueda");
        }
        List<ModeloEntrenador> resultados = entrenadores.values().stream()
                .filter(e -> request.nombreEntrenador() == null ||
                        e.nombreEntrenador().equalsIgnoreCase(request.nombreEntrenador()))
                .filter(e -> request.apellidoEntrenador1() == null ||
                        e.apellidoEntrenador1().equalsIgnoreCase(request.apellidoEntrenador1()))
                .collect(Collectors.toList());
        if (resultados.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontraron entrenadores con los criterios especificados");
        }

        return ResponseEntity.ok(resultados);
    }

    @GetMapping("/api/entrenadores")
    public ResponseEntity<List<ModeloEntrenador>> listarEntrenadores() {
        return ResponseEntity.ok(new ArrayList<>(entrenadores.values()));
    }

    @PutMapping("/api/equipos/{equipo}/entrenador")
    public ResponseEntity<?> actualizarEntrenador(
            @PathVariable String equipo,
            @RequestBody @Valid ModeloEntrenador nuevoEntrenador) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El equipo '" + equipo + "' no existe");
        }
        ModeloEntrenador entrenadorActualizado = new ModeloEntrenador(
                nuevoEntrenador.nombreEntrenador(),
                nuevoEntrenador.apellidoEntrenador1(),
                equipo
        );
        entrenadores.put(equipo, entrenadorActualizado);

        String entrenadorActualizadoStr = String.format("%s %s",
                entrenadorActualizado.nombreEntrenador(),
                entrenadorActualizado.apellidoEntrenador1());

        return ResponseEntity.ok(entrenadorActualizadoStr+" es el nuevo entrenador del "+entrenadorActualizado.nombreEquipo());
    }

    //JUGADORES


    @PostMapping("/api/equipos/{equipo}/jugador")
    public ResponseEntity<?> crearJugador(@PathVariable String equipo, @RequestBody @Valid ModeloJugador jugador) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + equipo + "' no existe");
        }
        dorsalesPorEquipo.putIfAbsent(equipo, new HashSet<>()); //Verifica la existencia del equipo
        if (dorsalesPorEquipo.get(equipo).contains(jugador.dorsalJugador())) {
            return ResponseEntity.badRequest()
                    .body("El dorsal " + jugador.dorsalJugador() + " ya está usado en " + equipo);
        }
        if (jugadoresPorEquipo.getOrDefault(equipo, List.of()).size() >= MAX_JUGADORES) {
            return ResponseEntity.badRequest()
                    .body("El equipo ya tiene " + MAX_JUGADORES + " jugadores (máximo permitido)");
        }
        ModeloJugador nuevoJugador = new ModeloJugador(
                jugador.nombreJugador(),
                jugador.apellidoJugador1(),
                jugador.dorsalJugador(),
                equipo
        );

        jugadoresPorEquipo.computeIfAbsent(equipo, k -> new ArrayList<>()).add(nuevoJugador);
        dorsalesPorEquipo.get(equipo).add(jugador.dorsalJugador());

        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoJugador);
    }

    @PostMapping("/api/jugadores/buscar")
    public ResponseEntity<?> buscarJugador(@RequestBody @Valid BusquedaJugadorRequest request) {
        if (request.nombre() == null &&
                request.apellido1() == null &&
                request.dorsal() == null &&
                request.equipo() == null) {
            return ResponseEntity.badRequest()
                    .body("Debe proporcionar al menos un criterio de búsqueda");
        }
        List<ModeloJugador> resultados = jugadoresPorEquipo.values().stream()
                .flatMap(List::stream)
                .filter(j -> request.nombre() == null ||
                        j.nombreJugador().equalsIgnoreCase(request.nombre()))
                .filter(j -> request.apellido1() == null ||
                        j.apellidoJugador1().equalsIgnoreCase(request.apellido1()))
                .filter(j -> request.dorsal() == null ||
                        j.dorsalJugador() == request.dorsal())
                .filter(j -> request.equipo() == null ||
                        j.nombreEquipo().equalsIgnoreCase(request.equipo()))
                .collect(Collectors.toList());
        if (resultados.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontraron jugadores con los criterios especificados");
        }

        return ResponseEntity.ok(resultados);
    }

    @GetMapping("/api/equipos/{equipo}/jugadores/{dorsal}")
    public ResponseEntity<?> obtenerJugadorPorDorsal(@PathVariable String equipo,@PathVariable int dorsal) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El equipo '" + equipo + "' no existe");
        }
        List<ModeloJugador> jugadores = jugadoresPorEquipo.getOrDefault(equipo, Collections.emptyList());
        Optional<ModeloJugador> jugadorEncontrado = jugadores.stream()
                .filter(j -> j.dorsalJugador() == dorsal)
                .findFirst();
        if (jugadorEncontrado.isPresent()) {
            return ResponseEntity.ok(jugadorEncontrado.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontró jugador con dorsal " + dorsal + " en " + equipo);
        }
    }


    @GetMapping("/api/jugadores/{equipo}")
    public ResponseEntity<?> obtenerJugadoresPorEquipo(@PathVariable String equipo) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + equipo + "' no existe");
        }
        Map<String, Object> respuesta = new LinkedHashMap<>();
        List<String> jugadoresFormateados = new ArrayList<>();
        List<ModeloJugador> jugadores = jugadoresPorEquipo.getOrDefault(equipo, Collections.emptyList());

        for (ModeloJugador jugador : jugadores) {
            String jugadorStr = String.format("%s %s, dorsal %d",
                    jugador.nombreJugador(),
                    jugador.apellidoJugador1(),
                    jugador.dorsalJugador());
            jugadoresFormateados.add(jugadorStr);
        }

        respuesta.put("nombreEquipo", equipo);
        respuesta.put("Numero de jugadores", jugadores.size());
        respuesta.put("Jugadores", jugadoresFormateados);

        return ResponseEntity.ok(respuesta);
    }
    @GetMapping("/api/jugadores")
    public ResponseEntity<?> obtenerTodosLosJugadores() {
        Map<String, Object> respuesta = new LinkedHashMap<>();
        Map<String, List<String>> jugadoresPorEquipoFormateados = new LinkedHashMap<>();
        int totalJugadores = 0;

        // Procesar jugadores de cada equipo
        for (Map.Entry<String, List<ModeloJugador>> entry : jugadoresPorEquipo.entrySet()) {
            String equipo = entry.getKey();
            List<ModeloJugador> jugadores = entry.getValue();
            List<String> jugadoresFormateados = new ArrayList<>();

            for (ModeloJugador jugador : jugadores) {
                String jugadorStr = String.format("%s %s, dorsal %d",
                        jugador.nombreJugador(),
                        jugador.apellidoJugador1(),
                        jugador.dorsalJugador());
                jugadoresFormateados.add(jugadorStr);
            }

            jugadoresPorEquipoFormateados.put(equipo, jugadoresFormateados);
            totalJugadores += jugadores.size();
        }

        respuesta.put("Numero total de jugadores", totalJugadores);
        respuesta.put("Numero de equipos", jugadoresPorEquipo.size());
        respuesta.put("Jugadores por equipo", jugadoresPorEquipoFormateados);

        return ResponseEntity.ok(respuesta);
    }

    @DeleteMapping("/api/equipos/{equipo}/jugadores/{dorsal}")
    public ResponseEntity<?> eliminarJugador(@PathVariable String equipo,@PathVariable int dorsal) {

        if (!jugadoresPorEquipo.containsKey(equipo)) {
            return ResponseEntity.notFound().build();
        }

        boolean removed = jugadoresPorEquipo.get(equipo).removeIf(j -> j.dorsalJugador() == dorsal);

        if (removed) {
            dorsalesPorEquipo.get(equipo).remove(dorsal); // Liberar el dorsal
            return ResponseEntity.ok("Jugador eliminado");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/api/equipos/{equipo}/jugadores/{dorsalActual}")
    public ResponseEntity<?> cambiarDorsalJugador(@PathVariable String equipo,@PathVariable int dorsalActual,@RequestBody @Valid CambioDorsalRequest nuevoDorsal) {
        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El equipo '" + equipo + "' no existe");
        }
        List<ModeloJugador> jugadores = jugadoresPorEquipo.getOrDefault(equipo, Collections.emptyList());
        Optional<ModeloJugador> jugadorOpt = jugadores.stream()
                .filter(j -> j.dorsalJugador() == dorsalActual)
                .findFirst();

        if (jugadorOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró jugador con dorsal " + dorsalActual + " en " + equipo);
        }

        if (dorsalesPorEquipo.get(equipo).contains(nuevoDorsal.nuevoDorsal())) {
            return ResponseEntity.badRequest()
                    .body("El dorsal " + nuevoDorsal.nuevoDorsal() + " ya está en uso en el equipo " + equipo);
        }

        ModeloJugador jugador = jugadorOpt.get();
        ModeloJugador jugadorActualizado = new ModeloJugador(
                jugador.nombreJugador(),
                jugador.apellidoJugador1(),
                nuevoDorsal.nuevoDorsal(),
                equipo
        );

        jugadores.remove(jugador);
        jugadores.add(jugadorActualizado);

        dorsalesPorEquipo.get(equipo).remove(dorsalActual);
        dorsalesPorEquipo.get(equipo).add(nuevoDorsal.nuevoDorsal());

        return ResponseEntity.ok("Dorsal cambiado de " + dorsalActual + " a " + nuevoDorsal.nuevoDorsal() +" para el jugador " + jugador.nombreJugador() + " " + jugador.apellidoJugador1());
    }

    @PutMapping("/api/equipos/{equipo}/jugadores/{dorsal}/nombre")
    public ResponseEntity<?> cambiarNombreJugador(
            @PathVariable String equipo,
            @PathVariable int dorsal,
            @RequestBody @Valid CambioNombreRequest nuevoNombre) {

        if (!equipos.containsKey(equipo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El equipo '" + equipo + "' no existe");
        }

        List<ModeloJugador> jugadores = jugadoresPorEquipo.get(equipo);
        Optional<ModeloJugador> jugadorOpt = jugadores.stream()
                .filter(j -> j.dorsalJugador() == dorsal)
                .findFirst();

        if (jugadorOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontró jugador con dorsal " + dorsal + " en " + equipo);
        }

        ModeloJugador jugador = jugadorOpt.get();
        ModeloJugador jugadorActualizado = new ModeloJugador(
                nuevoNombre.nombre(),
                nuevoNombre.apellido1(),
                dorsal,
                equipo
        );

        jugadores.remove(jugador);
        jugadores.add(jugadorActualizado);

        return ResponseEntity.ok(
                String.format("Nombre actualizado: %s %s (Dorsal %d)",
                        nuevoNombre.nombre(),
                        nuevoNombre.apellido1(),
                        dorsal)
        );
    }

    @PutMapping("/api/jugadores/transferir")
    public ResponseEntity<String> transferirJugador(@RequestBody @Valid TransferenciaRequest request) {
        String equipoOrigen = request.equipoOrigen();
        String equipoDestino = request.equipoDestino();
        int dorsal = request.dorsal();

        if (!equipos.containsKey(equipoOrigen)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Equipo origen no existe");
        }
        if (!equipos.containsKey(equipoDestino)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Equipo destino no existe");
        }

        jugadoresPorEquipo.putIfAbsent(equipoOrigen, new ArrayList<>());
        jugadoresPorEquipo.putIfAbsent(equipoDestino, new ArrayList<>());
        dorsalesPorEquipo.putIfAbsent(equipoOrigen, new HashSet<>());
        dorsalesPorEquipo.putIfAbsent(equipoDestino, new HashSet<>());

        Optional<ModeloJugador> jugadorOpt = jugadoresPorEquipo.get(equipoOrigen).stream()
                .filter(j -> j.dorsalJugador() == dorsal)
                .findFirst();

        if (jugadorOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Jugador con dorsal " + dorsal + " no encontrado en " + equipoOrigen);
        }

        if (dorsalesPorEquipo.get(equipoDestino).contains(dorsal)) {
            return ResponseEntity.badRequest()
                    .body("Dorsal " + dorsal + " ya está en uso en " + equipoDestino);
        }

        ModeloJugador jugador = jugadorOpt.get();
        jugadoresPorEquipo.get(equipoOrigen).remove(jugador);
        jugadoresPorEquipo.get(equipoDestino).add(new ModeloJugador(
                jugador.nombreJugador(),
                jugador.apellidoJugador1(),
                dorsal,
                equipoDestino
        ));

        dorsalesPorEquipo.get(equipoOrigen).remove(dorsal);
        dorsalesPorEquipo.get(equipoDestino).add(dorsal);

        return ResponseEntity.ok(
                String.format("%s %s transferido de %s a %s (Dorsal %d)",
                        jugador.nombreJugador(),
                        jugador.apellidoJugador1(),
                        equipoOrigen,
                        equipoDestino,
                        dorsal)
        );
    }
}
