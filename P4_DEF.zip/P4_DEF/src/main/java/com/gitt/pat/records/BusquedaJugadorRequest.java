package com.gitt.pat.records;

import jakarta.annotation.Nullable;

public record BusquedaJugadorRequest(
        @Nullable String nombre,
        @Nullable String apellido1,
        @Nullable Integer dorsal,
        @Nullable String equipo
) {}
