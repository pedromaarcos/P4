package com.gitt.pat.records;

public record TransferenciaRequest(
        String equipoOrigen,
        String equipoDestino,
        int dorsal
) {}
