package com.gitt.pat.records;

import jakarta.validation.constraints.NotBlank;

public record CambioNombreRequest(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        @NotBlank(message = "El primer apellido es obligatorio")
        String apellido1
) {}
