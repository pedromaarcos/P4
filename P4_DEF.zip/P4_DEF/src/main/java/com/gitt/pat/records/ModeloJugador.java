package com.gitt.pat.records;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.*;

public record ModeloJugador(
        @NotBlank(message = "El nombre no puede estar vacío")
        @Size(min = 2, max = 50, message = "El nombre debe tener entre 2 y 50 caracteres")
        @Pattern(regexp = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$", message = "Solo letras y espacios permitidos")
        String nombreJugador,

        @NotBlank(message = "El apellido no puede estar vacío")
        @Size(min = 2, max = 50, message = "El apellido debe tener entre 2 y 50 caracteres")
        @Pattern(regexp = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$", message = "Solo letras y espacios permitidos")
        String apellidoJugador1,


        @Min(value = 1, message = "El dorsal debe ser mayor a 0")
        @Max(value = 99, message = "El dorsal debe ser menor a 100")
        int dorsalJugador,

        @Nullable String nombreEquipo
) {}
