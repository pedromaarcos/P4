package com.gitt.pat.records;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record CambioDorsalRequest(
        @NotNull(message = "El nuevo dorsal es obligatorio")
        @Min(value = 1, message = "El dorsal debe ser mayor que 0")
        @Max(value = 99, message = "El dorsal debe ser menor que 100")
        int nuevoDorsal
) {}
